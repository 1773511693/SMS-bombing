﻿<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name='referrer' content="never">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta http-equiv="cache-control" content="no-siteapp">
<title>多开线路测压-增强版</title>
<meta name="keywords" content="木槿网络，木槿云短信测压,源码开发请联系QQ号1773511693">
<meta name="description" content="免费接口更新请访问<?php echo $_SERVER['HTTP_HOST']; ?>,QQ号1773511693，木槿网络开发组">
<link rel="shortcut icon" href="https://blog.xnsay.com/content/templates/vip_dux/favicon.ico">
</head>
<body>

<!--开始-->

<b>正在为该号进行云呼中...</b>
<p>本页为多开非挂机模式，将自动刷新一直轰炸</p>
<p>若需要停止轰炸，请联系站长QQ号即可</p>
<p>此页面可直接关闭，将由系统自动永久性云呼</p><br>
<meta http-equiv="refresh" content="30.1;url=/dy.php?hm=<?php echo $_GET['hm'];?>">
<iframe src="/index.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/api.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/index.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/api.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/index.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/api.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/index.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/api.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/index.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/api.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/index.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/api.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/index.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/api.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/index.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/api.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/index.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/api.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/index.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
<iframe src="/api.php?hm=<?php echo $_GET['hm'];?>&ok=" width="0"></iframe>
</div>
  <style>
    html,body{
      height: 100vh;
      width: 100vw;
      margin: 0;
      padding: 0;
      background: #ffffff;
      text-align: center;
      margin-top:30px;
      overflow: hidden;
    }
    *{
      color:rgb(100,100,100);
    }
    a{
      color:#42b983;
    }
    ul,li{
      margin: 0;
    }
    ul{
      margin-left: -40px;
      line-height: 30px;
    }
    li{
      list-style: none;
    }
  </style>
<!--结束-->
         <?php echo $aik['tongji'];?>
</body>
</html>
