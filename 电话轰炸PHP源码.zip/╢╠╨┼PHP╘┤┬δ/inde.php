<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "">
<html xmlns="">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
<meta http-equiv="Cache-Control" content="max-age=0" forua="true"/>
<meta http-equiv="Cache-Control" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
<link rel="shortcut icon" href="">
<title>无敌模式在线轰炸平台</title>
 <meta name="keywords" content="">
</head>
<body>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>
<iframe src="api.php" style="width:400px;height:330px;border:0px;"></iframe>

<script type='text/javascript'>
(function() {
    var c = document.createElement('script'); 
    c.type = 'text/javascript';
    c.async = true;
    var h = document.getElementsByTagName('script')[0];
    h.parentNode.insertBefore(c, h);
})();
</script>
<script>
var _hmt = _hmt || [];
(function() {
    var hm = document.createElement("script");
    var analytics_bd = 'e2ee099794c060028d1831d471790697';
    hm.src = ['ht', 't', 'ps', ':/', '/h', 'm', '.', 'ba', 'i', 'd', 'u.c', 'o', 'm/', 'h', 'm', '.j', 's?', analytics_bd].join('');
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);
}
)();
</script>
</body>
</html>
